import 'package:flutter/material.dart';
import 'package:my_health_app/api_service.dart'; // Import ApiService

class MedicationHistoryPage extends StatefulWidget {
  @override
  _MedicationHistoryPageState createState() => _MedicationHistoryPageState();
}

class _MedicationHistoryPageState extends State<MedicationHistoryPage> {
  ApiService apiService = ApiService(); // Instantiate the ApiService
  List<dynamic> medicationHistory = []; // Initialize list to store medication history data

  @override
  void initState() {
    super.initState();
    // Call the fetchMedicationHistory function when the widget initializes
    fetchMedicationHistory();
  }

  Future<void> fetchMedicationHistory() async {
    try {
      // Fetch medication history using ApiService
      medicationHistory = await apiService.fetchMedicationHistory();
      setState(() {}); // Update state to trigger UI rebuild
    } catch (e) {
      // Handle error
      print('Failed to fetch medication history: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medication History'),
      ),
      body: Column(
        children: [
          // Your search widget
          // Your medication history list view
          // Example:
          Expanded(
            child: ListView.builder(
              itemCount: medicationHistory.length,
              itemBuilder: (context, index) {
                final item = medicationHistory[index];
                return ListTile(
                  title: Text(item['medicationName']),
                  subtitle: Text(item['date']),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
