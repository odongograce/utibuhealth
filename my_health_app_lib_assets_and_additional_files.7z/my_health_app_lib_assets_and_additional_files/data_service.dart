import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

Future<List<Map<String, dynamic>>> fetchMockMedicationHistory() async {
  // Load the JSON file from assets
  String jsonString = await rootBundle.loadString('assets/medication_history.json');

  // Parse the JSON string into a list of maps
  List<dynamic> jsonData = json.decode(jsonString);
  List<Map<String, dynamic>> medicationHistory = List<Map<String, dynamic>>.from(jsonData);

  return medicationHistory;
}
