import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static const String baseUrl = 'https://your-auth-server.com/api';

  Future<bool> loginUser(String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        body: {
          'username': username,
          'password': password,
        },
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Login Error: $e');
      return false;
    }
  }

  Future<bool> registerUser(String username, String password, String email) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        body: {
          'username': username,
          'password': password,
          'email': email,
        },
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Registration Error: $e');
      return false;
    }
  }

  Future<List<dynamic>> fetchMedicationHistory() async {
    try {
      final response = await http.get(Uri.parse('http://localhost:3000/medication_history'));
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to load medication history');
      }
    } catch (e) {
      print('Medication History Error: $e');
      throw Exception('Failed to load medication history');
    }
  }
}
