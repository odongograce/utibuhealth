import 'package:flutter/material.dart';
import 'package:my_health_app/api_service.dart';

class LoginPage extends StatelessWidget {
  final ApiService apiService = ApiService();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void _login(BuildContext context) async {
    String username = usernameController.text;
    String password = passwordController.text;

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter username and password'),
        ),
      );
      return;
    }

    try {
      bool success = await apiService.loginUser(username, password);
      if (success) {
        Navigator.pushReplacementNamed(context, '/medication-history');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login failed. Please try again.'),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('An error occurred during login. Please try again later.'),
        ),
      );
      print('Login Error: $e');
    }
  }

  void _navigateToRegistration(BuildContext context) {
    Navigator.pushNamed(context, '/registration');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Welcome Back!',
                  style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold, color: Colors.blue),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: usernameController,
                  decoration: InputDecoration(
                    hintText: 'Enter your username',
                    labelText: 'Username',
                    border: OutlineInputBorder(),
                    fillColor: Colors.white,
                    filled: true,
                  ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Enter your password',
                    labelText: 'Password',
                    border: OutlineInputBorder(),
                    fillColor: Colors.white,
                    filled: true,
                  ),
                ),
                SizedBox(height: 16.0),
                Container(
                  width: double.infinity,
                  color: Colors.blue, // Change button color
                  child: ElevatedButton(
                    onPressed: () => _login(context),
                    child: Text('Login'),
                  ),
                ),
                SizedBox(height: 8.0),
                TextButton(
                  onPressed: () => _navigateToRegistration(context),
                  child: Text('Don\'t have an account? Register', style: TextStyle(color: Colors.blue)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
