import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:my_health_app/api_service.dart'; // Import your ApiService

class OrderMedicationPage extends StatefulWidget {
  @override
  _OrderMedicationPageState createState() => _OrderMedicationPageState();
}

class _OrderMedicationPageState extends State<OrderMedicationPage> {
  final TextEditingController medicationController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  String pickupOption = 'Pickup';

  // Instantiate ApiService
  final ApiService apiService = ApiService();

  void submitOrder(BuildContext context) async {
    String medication = medicationController.text;
    String quantity = quantityController.text;

    // Perform validation
    if (medication.isEmpty || quantity.isEmpty) {
      // Show error message if fields are empty
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter medication and quantity'),
        ),
      );
      return;
    }

    // Mock API endpoint for submitting orders
    final String apiUrl = 'https://example.com/api/orders';

    // Example order data
    Map<String, dynamic> orderData = {
      'medication': medication,
      'quantity': quantity,
      'pickupOption': pickupOption,
    };

    // Send POST request to submit order
    final response = await http.post(
      Uri.parse(apiUrl),
      body: orderData,
    );

    if (response.statusCode == 200) {
      // Order submitted successfully
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Order Confirmation'),
            content: Text('Your order has been submitted successfully.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Failed to submit order
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Failed to submit order. Please try again later.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order Medication'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: medicationController,
              decoration: InputDecoration(
                labelText: 'Medication',
                hintText: 'Enter medication name',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: quantityController,
              decoration: InputDecoration(
                labelText: 'Quantity',
                hintText: 'Enter quantity',
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            DropdownButtonFormField<String>(
              value: pickupOption,
              onChanged: (newValue) {
                setState(() {
                  pickupOption = newValue as String;
                });
              },
              items: ['Pickup', 'Delivery']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              decoration: InputDecoration(labelText: 'Pickup/Delivery'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () => submitOrder(context),
              child: Text('Submit Order'),
            ),
          ],
        ),
      ),
    );
  }
}
