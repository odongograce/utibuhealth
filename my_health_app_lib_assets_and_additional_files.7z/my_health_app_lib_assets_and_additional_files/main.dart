import 'package:flutter/material.dart';
import 'package:my_health_app/login_page.dart';
import 'package:my_health_app/medication_history_page.dart'; // Import your MedicationHistoryPage widget
import 'package:my_health_app/registration_page.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Utibu Health App',
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(),
        '/medication-history': (context) => MedicationHistoryPage(), // Define the MedicationHistoryPage widget for the '/medication-history' route
        '/registration': (context) => RegistrationPage(),
      },
    );
  }
}
